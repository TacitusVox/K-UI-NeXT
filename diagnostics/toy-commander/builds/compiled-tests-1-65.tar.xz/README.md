# Compiled Toy Commander test modules 1–65

The catalog preserves the original compiled KUI software from 44 recovered delivery and local-candidate ZIP archives. Module files are deduplicated by full SHA-256. Their original bytes and embedded build identifiers are retained.

`archive-members.json` maps each original archive member path to its catalog file, original size, SHA-256 and validated KUI envelope metadata. `modules.json` lists the 114 unique modules and all archive memberships. Each folder under `archives/` holds the original archive README, original SHA256SUMS.txt and an inventory with catalog paths. The README records how that historical test was intended to be installed and selected.

Use the evidence index alongside this catalog. An archive may contain several retained control modules, and a locally generated candidate may have been superseded before delivery. An original console report identifies its sampled reader using the embedded build. Package membership alone does not establish console acceptance.

The original ZIP files are identified by archive size and SHA-256. ZIP container bytes and timestamps are represented by those hashes. The catalog can recover each member's exact bytes and path. It does not recreate the original compressed ZIP byte stream.

`SHA256SUMS.txt` covers every catalog file except the checksum file itself. No game executable, disc image, movie, save or toolchain is included.

To verify the catalog, run `sha256sum -c SHA256SUMS.txt` after extraction. To restore a historical software tree, use the archive mapping to copy its `modules/` entries to their listed original `KUI/` paths. Choose one archive's complete software set so the Card Tools selector and reader module belong to the same test cohort.
